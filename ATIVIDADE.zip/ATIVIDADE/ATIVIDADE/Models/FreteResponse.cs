﻿namespace ApiExemplo.Models
{
    public class FreteResponse
    {
        public string Nome { get; set; }
        public double VolumeCm3 { get; set; }
        public double TaxaPorCm3 { get; set; }
        public double TaxaEstado { get; set; }
        public double ValorFrete { get; set; }
        public string Uf { get; set; }
    }
}