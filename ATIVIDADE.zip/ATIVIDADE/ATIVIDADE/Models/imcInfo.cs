﻿namespace ApiExemplo.Models
{
    public class ImcInfo
    {
        public double Imc { get; set; }
        public string Descricao { get; set; }
    }
}