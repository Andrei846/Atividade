﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;

namespace FreteApi.Controllers
{
   
    public class FreteRequest
    {
        public string Nome { get; set; }
        public double Peso { get; set; }     
        public double Altura { get; set; }      
        public double Largura { get; set; }   
        public double Comprimento { get; set; } 
        public string Uf { get; set; }       
    }

   
    public class TarifaEstado
    {
        public string Uf { get; set; }
        public double TaxaPorCm3 { get; set; } 
    }


    public class FreteResponse
    {
        public string Nome { get; set; }
        public string Uf { get; set; }
        public double Volume { get; set; }     
        public double Frete { get; set; }     
    }

    [ApiController]
    [Route("api/[controller]")]
    public class FreteController : ControllerBase
    {
       
        private static readonly List<TarifaEstado> tarifas = new List<TarifaEstado>
        {
            new TarifaEstado { Uf = "SP", TaxaPorCm3 = 0.01 },
            new TarifaEstado { Uf = "RJ", TaxaPorCm3 = 0.01 },
            new TarifaEstado { Uf = "MG", TaxaPorCm3 = 0.01 },
            new TarifaEstado { Uf = "OUTROS", TaxaPorCm3 = 0.01 }
        };


        [HttpPost("calcular")]
        public ActionResult<FreteResponse> CalcularFrete([FromBody] FreteRequest req)
        {
            if (req == null)
                return BadRequest("Objeto de requisição inválido.");


            if (string.IsNullOrWhiteSpace(req.Nome))
                return BadRequest("Nome é obrigatório.");
            if (req.Altura <= 0 || req.Largura <= 0 || req.Comprimento <= 0)
                return BadRequest("Dimensões devem ser maiores que zero.");
            if (string.IsNullOrWhiteSpace(req.Uf))
                return BadRequest("UF é obrigatória.");


            double volume = req.Altura * req.Largura * req.Comprimento;


            var tarifa = tarifas.FirstOrDefault(t => string.Equals(t.Uf, req.Uf, System.StringComparison.OrdinalIgnoreCase))
                         ?? tarifas.First(t => string.Equals(t.Uf, "OUTROS", System.StringComparison.OrdinalIgnoreCase));

            double frete = volume * tarifa.TaxaPorCm3;

            var resp = new FreteResponse
            {
                Nome = req.Nome,
                Uf = tarifa.Uf,
                Volume = volume,
                Frete = frete
            };

            return Ok(resp);
        }
            
       
        public IActionResult GetTarifas()
        {
            return Ok(tarifas);
        }
    }
}